import numpy as np
import matplotlib.pyplot as plt
from common import write_csv, save_plot

SEED = 707
DURATION = 300
CHANNELS = 20
DEVICES = 240
REPORT_DURATION = 1

def run():
    rng = np.random.default_rng(SEED)
    # Bursty telemetry: 6 reporting waves, each containing 40 devices.
    arrivals = []
    for wave in range(6):
        start = wave * 45
        arrivals.extend([(start, start+REPORT_DURATION, f"device_{wave}_{i}")
                         for i in range(DEVICES//6)])
    arrivals.sort()
    # Original: each report requires its own dedicated channel for the duration.
    dedicated_accepted = dedicated_blocked = dedicated_busy_seconds = 0
    busy_until = [0]*CHANNELS
    for start, end, _ in arrivals:
        free = next((i for i,t in enumerate(busy_until) if t <= start), None)
        if free is None:
            dedicated_blocked += 1
        else:
            busy_until[free] = end
            dedicated_accepted += 1
            dedicated_busy_seconds += end-start
    # Redesigned: reports enter a shared FIFO service queue; one server handles one report/sec.
    # Buffering prevents immediate blocking; all generated reports are served if queue is finite.
    queue = []
    service_time = 0
    delays = []
    for start, end, name in arrivals:
        queue.append((start, name))
    served = 0
    for arrival, name in queue:
        service_time = max(service_time, arrival) + 1
        delays.append(service_time-arrival)
        served += 1
    rows = [
        {"design": "dedicated_channels", "reports_offered": len(arrivals),
         "reports_delivered": dedicated_accepted, "reports_blocked_or_lost": dedicated_blocked,
         "resource_busy_seconds": dedicated_busy_seconds,
         "mean_delay_seconds": REPORT_DURATION if dedicated_accepted else 0},
        {"design": "shared_fifo_queue", "reports_offered": len(arrivals),
         "reports_delivered": served, "reports_blocked_or_lost": 0,
         "resource_busy_seconds": served, "mean_delay_seconds": round(float(np.mean(delays)), 3)}
    ]
    write_csv("Q7_results.csv", rows)
    plt.bar([r["design"] for r in rows], [r["reports_delivered"] for r in rows])
    plt.ylabel("Reports delivered")
    plt.xticks(rotation=10)
    save_plot("Q7_delivered_comparison.png")
    write_csv("Q7_assumptions.csv", [
        {"parameter": "simulation_duration_seconds", "value": DURATION},
        {"parameter": "devices", "value": DEVICES},
        {"parameter": "dedicated_channels", "value": CHANNELS},
        {"parameter": "report_waves", "value": 6},
        {"parameter": "service_rate", "value": "1 report per second"},
        {"parameter": "redesign", "value": "shared FIFO queue with buffering"}
    ])

if __name__ == "__main__":
    run()
