from Q1_Mobile_Computing.simulation import run as q1
from Q2_FDMA_TDMA.simulation import run as q2
from Q3_CDMA.simulation import run as q3
from Q4_OFDMA.simulation import run as q4
from Q5_SDMA.simulation import run as q5
from Q6_Multiple_Access_Comparison.comparison import run as q6
from Q7_Redesign_Validation.simulation import run as q7

if __name__ == "__main__":
    for label, experiment in [
        ("Q1", q1), ("Q2", q2), ("Q3", q3), ("Q4", q4),
        ("Q5", q5), ("Q6", q6), ("Q7", q7)
    ]:
        print(f"\nRunning {label}...")
        experiment()
    print("\nAll experiments completed. See the results/ folder.")
