import numpy as np
import matplotlib.pyplot as plt
from common import write_csv, save_plot, PLOTS

SEED = 202
DURATION = 600  # seconds
FDMA_CHANNELS = 72  # 2 MHz / 25 kHz = 80 nominal; 10% reserved for edge/control overhead
TDMA_CHANNELS = 72  # 10% of 80 nominal slots/carriers-equivalents reserved as overhead

def make_arrivals(kind, rng):
    if kind == "continuous_voice":
        return [(0, DURATION, f"c{i}") for i in range(55)]
    if kind == "bursty_data":
        events = []
        for i in range(120):
            start = int(rng.integers(0, DURATION-2))
            events.append((start, start+2, f"b{i}"))
        return events
    # Edge case: many devices start at the same instant.
    return [(0, 8, f"s{i}") for i in range(100)]

def allocate(events, channels):
    # Dedicated channel is held for the full call/report interval.
    busy_until = [0] * channels
    accepted = blocked = occupied_channel_seconds = 0
    for start, end, _ in sorted(events):
        free = next((i for i, t in enumerate(busy_until) if t <= start), None)
        if free is None:
            blocked += 1
        else:
            busy_until[free] = end
            accepted += 1
            occupied_channel_seconds += end-start
    total_capacity = channels * DURATION
    utilisation = occupied_channel_seconds / total_capacity
    return accepted, blocked, utilisation

def run():
    rng = np.random.default_rng(SEED)
    rows = []
    for traffic in ("continuous_voice", "bursty_data", "synchronised_edge_case"):
        events = make_arrivals(traffic, rng)
        for scheme, count in (("FDMA", FDMA_CHANNELS), ("TDMA", TDMA_CHANNELS)):
            accepted, blocked, util = allocate(events, count)
            rows.append({"traffic": traffic, "scheme": scheme, "effective_channels": count,
                         "offered_sessions": len(events), "accepted": accepted,
                         "blocked": blocked, "utilisation": round(util, 4),
                         "wasted_capacity_fraction": round(1-util, 4)})
    write_csv("Q2_results.csv", rows)
    # Capacity estimate from the assignment's 80 nominal channels.
    write_csv("Q2_capacity_estimate.csv", [
        {"scheme": "FDMA", "nominal_channels": 80, "assumed_overhead_percent": 10,
         "estimated_usable_channels": FDMA_CHANNELS},
        {"scheme": "TDMA", "nominal_channels": 80, "assumed_overhead_percent": 10,
         "estimated_usable_channels": TDMA_CHANNELS}
    ])
    labels = [r["traffic"] for r in rows[::2]]
    fdma = [r["utilisation"] for r in rows if r["scheme"] == "FDMA"]
    tdma = [r["utilisation"] for r in rows if r["scheme"] == "TDMA"]
    x = np.arange(len(labels))
    plt.bar(x-0.18, fdma, 0.36, label="FDMA")
    plt.bar(x+0.18, tdma, 0.36, label="TDMA")
    plt.xticks(x, labels, rotation=15)
    plt.ylabel("Channel utilisation")
    plt.legend()
    save_plot("Q2_utilisation.png")

if __name__ == "__main__":
    run()
