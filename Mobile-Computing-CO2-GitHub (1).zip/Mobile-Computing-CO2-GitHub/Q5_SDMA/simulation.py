import numpy as np
import matplotlib.pyplot as plt
from common import write_csv, save_plot

def array_factor_db(elements, angles_deg, steer_deg=0):
    theta = np.radians(angles_deg)
    steer = np.radians(steer_deg)
    phase = np.pi * (np.sin(theta)-np.sin(steer))
    denominator = np.sin(phase/2)
    numerator = np.sin(elements*phase/2)
    af = np.ones_like(phase)
    mask = np.abs(denominator) > 1e-12
    af[mask] = numerator[mask]/(elements*denominator[mask])
    return 20*np.log10(np.maximum(np.abs(af), 1e-6))

def run():
    angles = np.linspace(-90, 90, 3601)
    rows, beam_rows = [], []
    plt.figure()
    for n in (2, 4, 8, 16):
        pattern = array_factor_db(n, angles)
        positive = np.where(angles > 0.1)[0]
        null_candidates = positive[pattern[positive] < -50]
        first_null = angles[null_candidates[0]] if len(null_candidates) else 90
        beamwidth = 2*abs(first_null)
        sidelobes = pattern[(angles > first_null+1) & (angles < 90)]
        sidelobe_level = float(np.max(sidelobes)) if len(sidelobes) else float("nan")
        beam_rows.append({"elements": n, "approx_null_to_null_beamwidth_deg": round(beamwidth, 3),
                          "largest_right_side_lobe_db": round(sidelobe_level, 3)})
        for separation in range(5, 61, 5):
            interferer_gain_db = float(array_factor_db(n, np.array([separation]))[0])
            sir_db = -interferer_gain_db
            rows.append({"elements": n, "user_separation_deg": separation,
                         "interferer_relative_gain_db": round(interferer_gain_db, 3),
                         "estimated_sir_db": round(sir_db, 3),
                         "meets_10_db_sir": sir_db >= 10})
        plt.plot(angles, pattern, label=f"N={n}")
    write_csv("Q5_results.csv", rows)
    write_csv("Q5_beam_metrics.csv", beam_rows)
    plt.xlabel("Angle from broadside (degrees)")
    plt.ylabel("Normalised array factor (dB)")
    plt.ylim(-60, 2)
    plt.legend()
    save_plot("Q5_array_patterns.png")

if __name__ == "__main__":
    run()
