import random
from common import write_csv

SEED = 101

def classify_cases():
    return [
        {"case": "Rugged tablet using cellular work orders", "mobility": "Mobile",
         "connection": "Wireless", "main_focus": "Mobile communication + computing",
         "reason": "The user and device move; the app exchanges data over a cellular link."},
        {"case": "Laptop connected to Ethernet at different offices", "mobility": "Nomadic",
         "connection": "Wired at each location", "main_focus": "Mobile computing",
         "reason": "The device changes location but uses a fixed wired connection at each office."},
        {"case": "Fixed wireless router at remote substation", "mobility": "Fixed",
         "connection": "Wireless", "main_focus": "Communication",
         "reason": "The endpoint is stationary; only the access link is wireless."},
        {"case": "Push-to-talk handset", "mobility": "Mobile",
         "connection": "Wireless", "main_focus": "Mobile communication",
         "reason": "The primary function is real-time voice communication while moving."},
        {"case": "Tablet stores meter readings offline and syncs later", "mobility": "Mobile",
         "connection": "Intermittent wireless or wired sync", "main_focus": "Mobile computing",
         "reason": "The application must store data locally and tolerate disconnection."},
        {"case": "Ambiguous: field laptop in a parked service van using Wi-Fi",
         "mobility": "Nomadic while parked; mobile between sites",
         "connection": "Wireless", "main_focus": "Both",
         "reason": "Classification depends on whether mobility is judged during a session or across work locations."}
    ]

def simulate():
    rng = random.Random(SEED)
    rows = []
    n_updates = 1000
    for availability in (0.9, 0.6, 0.3):
        for strategy in ("immediate", "store_and_forward"):
            delivered = delayed = lost = 0
            delays = []
            for _ in range(n_updates):
                if strategy == "immediate":
                    if rng.random() < availability:
                        delivered += 1
                        delays.append(1.0)
                    else:
                        lost += 1
                else:
                    # Each update waits until one of the next 20 sync opportunities succeeds.
                    attempts = 0
                    while attempts < 20 and rng.random() >= availability:
                        attempts += 1
                    if attempts < 20:
                        delivered += 1
                        delay = attempts + 1
                        delays.append(delay)
                        if attempts:
                            delayed += 1
                    else:
                        lost += 1
            rows.append({
                "availability": availability, "strategy": strategy,
                "updates_total": n_updates, "delivered": delivered,
                "delayed": delayed, "lost": lost,
                "mean_delivery_delay_opportunities": round(sum(delays)/len(delays), 3) if delays else 0
            })
    return rows

def run():
    write_csv("Q1_classification.csv", classify_cases())
    write_csv("Q1_simulation.csv", simulate())

if __name__ == "__main__":
    run()
