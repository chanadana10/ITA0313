import numpy as np
from common import write_csv

SEED = 303

def walsh_codes(length):
    H = np.array([[1.0]])
    while len(H) < length:
        H = np.block([[H, H], [H, -H]])
    return H

def run():
    rng = np.random.default_rng(SEED)
    rows, correlations = [], []
    bits_per_user = 2000
    for length in (8, 16, 64):
        codes = walsh_codes(length)
        processing_gain_db = 10*np.log10(length)
        correlations.append({"code_length": length, "processing_gain_db": round(processing_gain_db, 3),
                             "max_abs_normalised_cross_correlation":
                             round(float(np.max(np.abs((codes @ codes.T)/length - np.eye(length)))), 6)})
        for condition in ("synchronous_equal_power", "random_codes_equal_power",
                          "synchronous_near_far_10x"):
            for users in (2, 4, 8):
                user_bits = rng.choice([-1.0, 1.0], size=(users, bits_per_user))
                if condition == "random_codes_equal_power":
                    user_codes = rng.choice([-1.0, 1.0], size=(users, length))
                else:
                    user_codes = codes[:users].copy()
                powers = np.ones(users)
                if condition == "synchronous_near_far_10x" and users > 1:
                    powers[1] = 10.0
                errors = 0
                for target in range(users):
                    # Chip-level sum; synchronous rectangular BPSK model, no channel noise.
                    signal = np.zeros((bits_per_user, length))
                    for u in range(users):
                        signal += (user_bits[u, :, None] * user_codes[u][None, :]
                                   * np.sqrt(powers[u]))
                    decision = np.sum(signal * user_codes[target][None, :], axis=1)
                    detected = np.where(decision >= 0, 1.0, -1.0)
                    errors += int(np.sum(detected != user_bits[target]))
                total = users * bits_per_user
                rows.append({"code_length": length, "condition": condition, "users": users,
                             "bits_tested": total, "bit_errors": errors,
                             "ber": round(errors/total, 6),
                             "processing_gain_db": round(processing_gain_db, 3)})
    write_csv("Q3_results.csv", rows)
    write_csv("Q3_code_correlation.csv", correlations)

if __name__ == "__main__":
    run()
