from pathlib import Path
import csv
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parent
RESULTS = ROOT / "results"
PLOTS = RESULTS / "plots"
RESULTS.mkdir(exist_ok=True)
PLOTS.mkdir(exist_ok=True)

def write_csv(filename, rows):
    if not rows:
        return
    path = RESULTS / filename
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)
    print(f"Saved {path.relative_to(ROOT)}")

def save_plot(filename):
    plt.tight_layout()
    plt.savefig(PLOTS / filename, dpi=160)
    plt.close()
