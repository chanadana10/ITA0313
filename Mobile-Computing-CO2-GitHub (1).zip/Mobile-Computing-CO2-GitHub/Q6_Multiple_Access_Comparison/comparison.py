from common import write_csv

# Scores are reasoned educational ratings from 1 (poor) to 5 (strong).
CRITERIA = {
    "mobility_and_coverage": 0.25,
    "capacity_and_spectral_efficiency": 0.25,
    "interference_robustness": 0.20,
    "burst_efficiency": 0.15,
    "implementation_scalability": 0.15
}
METHODS = ["SDMA", "TDMA", "FDMA", "CDMA", "OFDMA"]
DEPLOYMENTS = {
    "wide_area_cellular_voice": {
        "SDMA": [4,4,3,3,3], "TDMA": [4,3,3,2,4], "FDMA": [4,2,3,2,4],
        "CDMA": [4,4,4,4,3], "OFDMA": [5,5,4,5,4]},
    "jam_resistant_tactical_link": {
        "SDMA": [3,3,3,3,3], "TDMA": [3,3,3,2,4], "FDMA": [3,2,3,2,4],
        "CDMA": [4,4,5,4,3], "OFDMA": [3,4,3,4,4]},
    "high_rate_stadium_downlink": {
        "SDMA": [4,4,4,3,3], "TDMA": [3,2,3,2,4], "FDMA": [3,2,3,2,4],
        "CDMA": [3,3,3,3,3], "OFDMA": [5,5,4,5,5]},
    "5000_low_rate_sensors": {
        "SDMA": [3,3,3,3,2], "TDMA": [4,3,3,2,4], "FDMA": [3,2,3,1,3],
        "CDMA": [4,4,4,4,3], "OFDMA": [4,4,4,4,4]}
}

def score(vector, weights):
    return sum(v*w for v, w in zip(vector, weights.values()))

def run():
    rows, sensitivity = [], []
    weights = dict(CRITERIA)
    for deployment, ratings in DEPLOYMENTS.items():
        scores = {method: score(ratings[method], weights) for method in METHODS}
        winner = max(scores, key=scores.get)
        for method in METHODS:
            rows.append({"deployment": deployment, "method": method,
                         "weighted_score_out_of_5": round(scores[method], 3),
                         "selected": method == winner})
        for factor in (0.8, 1.2):
            changed = {k: v*(factor if k == "capacity_and_spectral_efficiency" else 1)
                       for k, v in weights.items()}
            total = sum(changed.values())
            changed = {k: v/total for k, v in changed.items()}
            changed_scores = {m: score(ratings[m], changed) for m in METHODS}
            sensitivity.append({"deployment": deployment, "capacity_weight_factor": factor,
                                "original_choice": winner,
                                "choice_after_weight_change": max(changed_scores, key=changed_scores.get)})
    write_csv("Q6_results.csv", rows)
    write_csv("Q6_sensitivity.csv", sensitivity)
    write_csv("Q6_criteria_weights.csv", [{"criterion": k, "weight": v} for k,v in weights.items()])

if __name__ == "__main__":
    run()
