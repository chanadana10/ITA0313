import numpy as np
import matplotlib.pyplot as plt
from common import write_csv, save_plot

SEED = 404
USERS = 8
SUBCARRIERS = 64
REALISATIONS = 1000
NOISE = 0.15

def jain(values):
    values = np.asarray(values, dtype=float)
    return float(values.sum()**2/(len(values)*(values**2).sum())) if (values**2).sum() else 0.0

def verify_orthogonality():
    n = np.arange(256)
    freqs = (1, 2, 3)
    signals = [np.exp(2j*np.pi*k*n/256) for k in freqs]
    return [{"subcarrier_a": freqs[i], "subcarrier_b": freqs[j],
             "normalised_inner_product": round(float(abs(np.vdot(signals[i], signals[j]))/256), 10)}
            for i in range(3) for j in range(i+1, 3)]

def run():
    rng = np.random.default_rng(SEED)
    totals = {name: np.zeros(USERS) for name in ("fixed_block", "round_robin", "channel_aware")}
    for _ in range(REALISATIONS):
        gains = rng.exponential(1.0, size=(USERS, SUBCARRIERS))
        # One user per subcarrier. Each subcarrier contributes log2(1+SNR).
        fixed_owner = np.repeat(np.arange(USERS), SUBCARRIERS//USERS)
        rr_owner = np.arange(SUBCARRIERS) % USERS
        aware_owner = np.argmax(gains, axis=0)
        for name, owners in (("fixed_block", fixed_owner), ("round_robin", rr_owner),
                             ("channel_aware", aware_owner)):
            for sc, user in enumerate(owners):
                totals[name][user] += np.log2(1 + gains[user, sc]/NOISE)
    rows = []
    for name, accumulated in totals.items():
        per_user = accumulated / REALISATIONS
        for user, throughput in enumerate(per_user):
            rows.append({"allocation": name, "user": user+1,
                         "average_throughput": round(float(throughput), 4),
                         "sum_throughput": round(float(per_user.sum()), 4),
                         "jains_fairness": round(jain(per_user), 4)})
    write_csv("Q4_results.csv", rows)
    write_csv("Q4_orthogonality.csv", verify_orthogonality())
    names = list(totals)
    sums = [sum(totals[n]/REALISATIONS) for n in names]
    fairness = [jain(totals[n]/REALISATIONS) for n in names]
    plt.bar(names, sums)
    plt.ylabel("Average sum throughput (bits/s/Hz model)")
    plt.xticks(rotation=12)
    save_plot("Q4_sum_throughput.png")
    plt.bar(names, fairness)
    plt.ylabel("Jain's fairness index")
    plt.ylim(0, 1.05)
    plt.xticks(rotation=12)
    save_plot("Q4_fairness.png")

if __name__ == "__main__":
    run()
